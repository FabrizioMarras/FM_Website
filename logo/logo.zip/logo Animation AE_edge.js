
(function(compId){var _=null,y=true,n=false,zy='scaleY',x20='Rectangle5',x3='5.0.0',x27='rgba(0,0,0,0)',x17='rgb(0, 0, 0)',zx='scaleX',po='center',x34='Facebook_button',x21='Rectangle6',x26='Instagram_button',e10='${F_low_bar}',e9='${M_mid_bar}',x25='rgba(255,0,0,1)',m='rect',e12='${F_top_bar}',x5='horizontal',i='none',x18='rgba(247,147,29,1)',x4='6.0.0.400',p='px',x16='Rectangle4',lf='left',e7='${M_left_bar}',x19='179px',e8='${M_right_bar}',x32='about_button',x22='Rectangle7',x='text',l='normal',x31='rgba(255,255,255,1.00)',x15='auto',x24='Rectangle8',x30='Arial, Helvetica, sans-serif',x29='0px',e11='${F_mid_bar}',w='width',tp='top',g='image',x2='6.0.0',x13='36px',x6='rgba(255,255,255,0.00)',x23='rgba(255,0,0,1.00)',x14='120px';var g1='jquery-2.0.3.min.js',g35='Facebook.png',g28='Instagram.png';var s33="ABOUT";var im='images/',aud='media/',vid='media/',js='js/',fonts={},opts={'gAudioPreloadPreference':'auto','gVideoPreloadPreference':'auto'},resources=[],scripts=[js+g1],symbols={"stage":{v:x2,mv:x3,b:x4,stf:w,cg:x5,rI:n,cn:{dom:[{id:'Logo',t:'group',r:['-95px','-96px','240px','241px','auto','auto'],cu:'pointer',tf:[[],[],[],['0.15','0.15']],c:[{id:'M_left_bar',symbolName:'M-left_bar',t:m,r:['67','-359','36','120','auto','auto'],o:'1',tf:[[],['-180']]},{id:'M_mid_bar',symbolName:'M_mid_bar',t:m,r:['136','-359','36','179','auto','auto'],o:'1',tf:[[],['-180']]},{id:'M_right_bar',symbolName:'M_right_bar',t:m,r:['204','-359','36','241','auto','auto'],tf:[[],[],[],['0.99']]},{id:'F_low_bar',symbolName:'F_low_bar',t:m,r:['0','350','36','120','auto','auto'],o:'1',tf:[[],[],[],['0.05','0']]},{id:'F_mid_bar',symbolName:'F_mid_bar',t:m,r:['360','61','104','36','auto','auto'],o:'1',tf:[[],[],[],['0','0.05']]},{id:'F_top_bar',symbolName:'F_mid_bar',t:m,r:['394','0','104','36','auto','auto'],tf:[[],[],[],['0','0.05']]}]}],style:{'${Stage}':{isStage:true,r:['null','null','50px','50px','auto','auto'],overflow:'hidden',f:[x6]}}},tt:{d:3000,a:y,l:{"animation":0,"Stop_animation":3000},data:[["eid26",tp,1250,1500,"easeOutBounce",e7,'-359px','121px'],["eid31",tp,1250,1500,"easeOutBounce",e8,'-359px','0px'],["eid29",tp,1250,1500,"easeOutBounce",e9,'-359px','62px'],["eid154",tp,0,1000,"easeOutBack",e10,'350px','121px'],["eid80",zx,250,750,"easeOutQuad",e11,'0','1'],["eid72",zx,750,250,"easeOutQuad",e10,'0.05','1'],["eid78",zy,0,750,"easeOutQuad",e10,'0','1'],["eid160",lf,500,1000,"easeOutBack",e12,'394px','34px'],["eid86",zy,1000,250,"easeOutQuad",e11,'0.05','1'],["eid159",lf,250,1000,"easeOutBack",e11,'360px','0px'],["eid87",zx,500,750,"easeOutQuad",e12,'0','1.65385'],["eid88",zy,1250,250,"easeOutQuad",e12,'0.05','1']]}},"M-left_bar":{v:x2,mv:x3,b:x4,stf:i,cg:i,rI:n,cn:{dom:[{r:[0,0,x13,x14,x15,x15],id:x16,s:[0,x17,i],t:m,f:[x18]}],style:{'${symbolSelector}':{r:[_,_,36,120]}}},tt:{d:0,a:y,data:[]}},"M_mid_bar":{v:x2,mv:x3,b:x4,stf:i,cg:i,rI:n,cn:{dom:[{r:[0,0,x13,x19,x15,x15],id:x20,s:[0,x17,i],t:m,f:[x18]}],style:{'${symbolSelector}':{r:[_,_,36,179]}}},tt:{d:0,a:y,data:[]}},"M_right_bar":{v:x2,mv:x3,b:x4,stf:i,cg:i,rI:n,cn:{dom:[{r:[0,0,x13,241,x15,x15],id:x21,s:[0,x17,i],t:m,f:[x18]}],style:{'${symbolSelector}':{r:[_,_,36,241]}}},tt:{d:0,a:y,data:[]}},"F_low_bar":{v:x2,mv:x3,b:x4,stf:i,cg:i,rI:n,cn:{dom:[{r:[0,0,x13,x14,x15,x15],id:x22,s:[0,x17,i],t:m,f:[x23]}],style:{'${symbolSelector}':{r:[_,_,36,120]}}},tt:{d:0,a:y,data:[]}},"F_mid_bar":{v:x2,mv:x3,b:x4,stf:i,cg:i,rI:n,cn:{dom:[{r:[0,0,104,36,x15,x15],id:x24,s:[0,x17,i],t:m,f:[x25]}],style:{'${symbolSelector}':{r:[_,_,104,36]}}},tt:{d:0,a:y,data:[]}},"Inst_icon":{v:x2,mv:x3,b:x4,stf:i,cg:i,rI:n,cn:{dom:[{id:x26,t:g,r:[0,0,231,231,x15,x15],f:[x27,im+g28,x29,x29]}],style:{'${symbolSelector}':{r:[_,_,231,231]}}},tt:{d:0,a:y,data:[]}},"About_icon":{v:x2,mv:x3,b:x4,stf:i,cg:i,rI:n,cn:{dom:[{n:[x30,[43,p],x31,l,i,''],t:x,id:x32,text:s33,align:po,r:[0,0,231,53,x15,x15]}],style:{'${symbolSelector}':{r:[_,_,231,53]}}},tt:{d:0,a:y,data:[]}},"FB_icon":{v:x2,mv:x3,b:x4,stf:i,cg:i,rI:n,cn:{dom:[{id:x34,t:g,r:[0,0,231,231,x15,x15],f:[x27,im+g35,x29,x29]}],style:{'${symbolSelector}':{r:[_,_,231,231]}}},tt:{d:0,a:y,data:[]}}};AdobeEdge.registerCompositionDefn(compId,symbols,fonts,scripts,resources,opts);})("EDGE-116411097");
(function($,Edge,compId){var Composition=Edge.Composition,Symbol=Edge.Symbol;Edge.registerEventBinding(compId,function($){
//Edge symbol: 'stage'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",3000,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${Stage}","click",function(sym,e){sym.play();});
//Edge binding end
})("stage");
//Edge symbol end:'stage'

//=========================================================

//Edge symbol: 'M-left_bar'
(function(symbolName){})("M-left_bar");
//Edge symbol end:'M-left_bar'

//=========================================================

//Edge symbol: 'M_mid_bar'
(function(symbolName){})("M_mid_bar");
//Edge symbol end:'M_mid_bar'

//=========================================================

//Edge symbol: 'M_right_bar'
(function(symbolName){})("M_right_bar");
//Edge symbol end:'M_right_bar'

//=========================================================

//Edge symbol: 'F_low_bar'
(function(symbolName){})("F_low_bar");
//Edge symbol end:'F_low_bar'

//=========================================================

//Edge symbol: 'F_mid_bar'
(function(symbolName){})("F_mid_bar");
//Edge symbol end:'F_mid_bar'

//=========================================================

//Edge symbol: 'Inst_icon'
(function(symbolName){})("Inst_icon");
//Edge symbol end:'Inst_icon'

//=========================================================

//Edge symbol: 'About_icon'
(function(symbolName){})("About_icon");
//Edge symbol end:'About_icon'

//=========================================================

//Edge symbol: 'FB_icon'
(function(symbolName){})("FB_icon");
//Edge symbol end:'FB_icon'
})})(AdobeEdge.$,AdobeEdge,"EDGE-116411097");